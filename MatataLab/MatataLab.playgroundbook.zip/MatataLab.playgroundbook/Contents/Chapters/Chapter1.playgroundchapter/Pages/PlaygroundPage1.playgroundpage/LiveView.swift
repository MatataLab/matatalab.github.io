import UIKit
import Foundation
import PlaygroundSupport
import PlaygroundBluetooth

public let viewController : LiveViewController = LiveViewController("page_1.png", "page_1.png")
PlaygroundPage.current.liveView = viewController
