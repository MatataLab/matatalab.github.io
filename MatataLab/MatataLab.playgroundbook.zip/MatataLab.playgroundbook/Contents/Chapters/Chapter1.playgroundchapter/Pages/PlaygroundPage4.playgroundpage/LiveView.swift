import UIKit
import Foundation
import PlaygroundSupport
import PlaygroundBluetooth

public let viewController : LiveViewController = LiveViewController("page_4.png", "page_4.png")
PlaygroundPage.current.liveView = viewController
