import UIKit
import Foundation
import PlaygroundSupport
import PlaygroundBluetooth

public let viewController : LiveViewController = LiveViewController("page_0.png", "page_0.png")
PlaygroundPage.current.liveView = viewController
