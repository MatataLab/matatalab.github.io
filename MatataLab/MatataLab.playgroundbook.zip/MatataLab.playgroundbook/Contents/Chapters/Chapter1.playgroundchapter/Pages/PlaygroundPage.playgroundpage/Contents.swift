//#-hidden-code
//
//  Contents.swift
//
//  Creat by GtyFour 2019-01-02 15:33:23
//


import UIKit
import CoreBluetooth
import PlaygroundBluetooth
import PlaygroundSupport



//#-end-hidden-code
/*:
 Goal：command Matatabot to walk along the map path.
 
 Command Matatabot to move on the map and to arrive at the destination by programming .
 
 Call moveForward(),turnRight() turnLeft()and some other basic motion function.
 > Connect to your MatataBot before you start!!
 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveForward(), turnLeft(), turnRight())
//#-hidden-code
setup()
cleancode()
//#-end-hidden-code
//#-editable-code Tap to enter your Code!!
//#-end-editable-code
//#-hidden-code
runcode()
//#-end-hidden-code
