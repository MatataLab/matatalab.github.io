import UIKit
import Foundation
import PlaygroundSupport
import PlaygroundBluetooth

public let viewController : LiveViewController = LiveViewController("page_5.png", "page_5.png")
PlaygroundPage.current.liveView = viewController
