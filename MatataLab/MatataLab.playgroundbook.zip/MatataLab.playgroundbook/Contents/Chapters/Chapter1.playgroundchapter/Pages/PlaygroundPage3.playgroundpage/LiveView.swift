import UIKit
import Foundation
import PlaygroundSupport
import PlaygroundBluetooth

public let viewController : LiveViewController = LiveViewController("page_3.png", "page_3.png")
PlaygroundPage.current.liveView = viewController
